# My Money — Personal Budget

A personal, installable web app with a soft pink design.

## Features
- Editable weekly and fortnightly income assumptions
- Record income and spending
- Savings goals for July, a car, and university abroad
- Christmas gift list with editable costs
- Rule-based budgeting coach (no AI API bill)
- Export/import JSON backup
- Offline cache after first load; installable as a PWA when served over HTTPS

## Free hosting
You can publish this static app using GitHub Pages or Netlify's free tier. Hosting providers can change their terms and limits; check current terms before publishing.

### Generic steps
1. Create a new repository on GitHub and upload `index.html`, `manifest.json`, `sw.js`, and `icon.svg`.
2. In repository Settings → Pages, enable deployment from the main branch and root folder.
3. Open the HTTPS URL from your phone or computer.
4. On Android/Chrome, use the browser menu → Install app or Add to Home screen. On iPhone/Safari, use Share → Add to Home Screen.
5. Open the app on each device. **Data does not automatically sync** between devices because this version stores data locally in each browser. Use Settings → Export backup on one device, then Import backup on the other.

## Important limitations
- No bank connection or automatic bank transaction import.
- The coach uses built-in rules, not a large language model. It has no ongoing AI cost and does not send your entries anywhere.
- Browser storage is local to each device/browser and can be cleared by the browser. Export backups regularly.
- This app is a personal planning aid, not financial advice.
- Do not put bank passwords, card details, or sensitive information into it.

## Test locally
For PWA/service-worker features, serve over localhost or HTTPS rather than opening the file directly. For example, if you have Python installed, run `python -m http.server 8000` from this folder and open `http://localhost:8000`.
